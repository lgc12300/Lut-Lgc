# -*- coding: utf-8 -*-

"""
@Time ： 2023/7/31 19:55
@File ： config.py
@Auth ： markz
"""

# 数据目录路径
log_dir = "./log"  # 日志文件夹目录路径
data_dir = "./data"  # 数据文件夹目录路径
friends_dir = f"{data_dir}/friends"  # 存放好友数据的目录名称
error_friends_dir = f"{data_dir}/error_friends"  # 存放错误数据的目录名称

# 用户唯一标识
# uid = "1234552257" # 成龙
# uid = "1195242865"  # 杨幂
uid = "1192329374"  # 谢娜
# uid = 1195230310 # 何炅
# uid = 7835485775

# 爬取页数
pages = 10

# 爬取多少条数据
max_number = 8000

cookie = "_T_WM=3888ce480d2a90038260c2988d7351c8; SCF=AigUWVnrC40ZJeYhQC0n_Q3SSrNF8dpOcI9FErEtLiQWweJNe5mZEWvZm-KJjMyKzQvnjcDOxancFmGdLE_PGDc.; SUB=_2A25JydM2DeRhGeRM61ET8inIyDuIHXVrNf1-rDV6PUJbktANLWXxkW1NU-MUOUp_aBL08EsYybV4e--mWPcdUNUV; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WhxCe2dVdWCB18SVTbFq8nK5JpX5K-hUgL.FozEeheEeoMXe0M2dJLoI7RLxK-LB.eLBK541KqcS7tt; SSOLoginState=1691198310; ALF=1693790310"

# 请求标头
headers = {
    "authority": "weibo.com",
    "x-requested-with": "XMLHttpRequest",
    "sec-ch-ua-mobile": "?0",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "content-type": "application/x-www-form-urlencoded",
    "accept": "*/*",
    "sec-fetch-site": "same-origin",
    "sec-fetch-mode": "cors",
    "sec-fetch-dest": "empty",
    "referer": "https://weibo.com/1192329374/KnnG78Yf3?filter=hot&root_comment_id=0&type=comment",
    "accept-language": "zh-CN,zh;q=0.9,en-CN;q=0.8,en;q=0.7,es-MX;q=0.6,es;q=0.5",
    "cookie": cookie
}
