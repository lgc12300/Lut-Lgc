# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/1 22:07
@File ： sql_config.py
@Auth ： markz
"""

# 数据库连接信息
db_config = {
    "host": "localhost",
    "port": 3307,
    "user": "root",
    "password": "root",
    "database": "weibo_user",
    "charset": "utf8"
}

# 表名
table_name = "weibo_user"  # 边表
info_table = "user_info"  # 节点表
