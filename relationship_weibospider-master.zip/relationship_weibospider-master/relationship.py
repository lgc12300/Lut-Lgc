# -*- coding: utf-8 -*-

"""
@Time ： 2023/7/25 10:58
@File ： main.py
@Auth ： markz
"""
import random

import time

from collections import deque

import pandas as pd

import sys

from 爬虫V2.config import crawler_config as config

from core.get_user_info import UserInfo

from core.info_to_csv import friends_info_to_csv, file_exist, error_info_to_csv, count_files_in_folder


def init_app(user_info):
    """
    初始化 csv 文件

    :param user_info: UserInfo 实例
    :return:
    """

    print("初始化...")

    if file_exist(f"{config.friends_dir}/{config.uid}.csv") is False:
        # 初始化 csv 文件
        init_info = user_info.get_user_friends_info(pages=config.pages)

        if not init_info.get("error_code") == 404:
            friends_info_to_csv(init_info)
            print("初始化完毕")
        else:
            print("初始化失败")


def fetch_friends(uids_deque, user_info, headers=config.headers, pages=config.pages):
    """
    通过队列广度优先爬取 from_uid 为起点的所有好友

    :param uids_deque: 存放 uids 的双端队列
    :param user_info: UserInfo 实例
    :param headers: 标头
    :param pages: 爬取页码
    :return:
    """

    while len(uids_deque) != 0:

        time.sleep(random.uniform(0.2, 2))

        # 达到爬取上限则断开
        if count_files_in_folder() > config.max_number:
            break

        from_uid = uids_deque.popleft()  # 从头部弹出一个元素

        # 读取 csv 文件到 DataFrame
        try:
            csv_file_name = f"{config.friends_dir}/{from_uid}.csv"
            df = pd.read_csv(csv_file_name)
        except FileNotFoundError:
            print(f"文件未找到 {from_uid}.csv，请检查文件是否存在或初始化")
            sys.exit()

        # 获取所有 uid 的唯一值
        uids = df["uid"].unique()

        for i, uid in enumerate(uids):
            errors_count = 0  # 记录错误数，如果连续 20 次返回 404，说明需要更换 cookie 或封号了

            # 进队
            uids_deque.append(uid)

            # 如果 uid 文件存在，代表当前 uid 已经爬过，跳过
            if file_exist(f"{config.friends_dir}/{uid}.csv"):
                print(f"用户 {uid} 已爬取...  {i + 1}/{len(uids)}")
                continue

            print(f"正在爬取 {uid}...  {i + 1}/{len(uids)}")
            user_friends_info = user_info.get_user_friends_info(uid, headers, pages)  # 爬取当前 uid 关注信息

            # 记录没爬到信息的 uid，并保存 csv
            if user_friends_info.get("error_code") == 404:
                print(f"用户 {uid} 不存在或设置隐私关注...  {i + 1}/{len(uids)}")
                error_uid = user_friends_info.get("uid")
                error_info_to_csv(uid=error_uid)

                errors_count += 1
                if errors_count >= 19:
                    print("【ERROR】请更换 cookie 或检查是否封号！")
                    sys.exit()

                # 爬取失败的 id 要弹出队列
                uids_deque.pop()
                continue

            # 爬到的当前用户朋友关系保存至 csv
            friends_info_to_csv(user_friends_info)


if __name__ == "__main__":
    """
        爬取微博关注
    """

    user = UserInfo(uid=config.uid, headers=config.headers)
    init_app(user)

    deque = deque()  # 初始化双端队列
    deque.append(config.uid)  # 入队第一个 uid

    fetch_friends(uids_deque=deque, user_info=user, pages=10)

    print("=" * 50)
    print(f"爬取完毕，请检查目录：{config.data_dir}")
