# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/2 16:40
@File ： clean.py
@Auth ： markz
"""
import time

import pymysql

from 爬虫V2.config.db_config import db_config

import pandas as pd

"""
    致命错误：应该使用MySQL语句筛选数据，而不是把MySQL当做存储数据的容器。
    思路：A 得关注中有 B，如果 B 的关注中有 A 则说明互关
    
"""

# 创建 DataFrame 存储互关关系
df = pd.DataFrame(columns=['uid_1', 'uid_2', 'screen_name'])
# 记录互关数量
count = 0
# 记录开始时间
start_time = time.process_time()

# 创建连接
conn = pymysql.connect(**db_config)

# 创建一个游标对象
cursor = conn.cursor()

# 查找数据条数
query_1 = "SELECT COUNT(*) FROM user_relationship;"
cursor.execute(query_1)
# 一共有多少数据
data_count = cursor.fetchone()[0]

# 一行一行查找
for i in range(data_count + 1):
    # 查找第 i 行数据
    query_2 = f"SELECT * FROM user_relationship LIMIT 1 OFFSET {i};"
    cursor.execute(query_2)
    # 第 i 行数据
    data_line = cursor.fetchall()

    # 找出第 i 行的 uid、screen_name、from_uid
    uid_i = data_line[0][0]
    screen_name_i = data_line[0][1]
    from_uid_i = data_line[0][2]

    # from_uid_i 关注了 uid_i，搜索 uid_i 关注的所有人
    query_3 = f"SELECT uid FROM user_relationship WHERE from_uid = '{uid_i}'"
    cursor.execute(query_3)
    uid_i_friends_list = cursor.fetchall()  # uid_i 关注的所有人
    # 如果存在，在他的所有关注中搜索是否有第 i 行中的 from_uid
    if len(uid_i_friends_list) != 0:
        for uid_i_friend in uid_i_friends_list:
            # 有说明两人互关
            if uid_i_friend[0] == from_uid_i:
                count += 1  # 互关数量 + 1
                data = [uid_i, from_uid_i, screen_name_i]
                print(f"{count}，{uid_i}与{from_uid_i}互关")

print(f"查找完毕，共 {count} 对互关")
