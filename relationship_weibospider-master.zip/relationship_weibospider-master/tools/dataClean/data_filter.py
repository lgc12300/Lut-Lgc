# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/3 15:29
@File ： filter_interdependencies.py
@Auth ： markz
"""

"""
       数据清洗：筛选互关
"""

import time

import pandas as pd

import pymysql

from 爬虫V2.config.db_config import db_config


def filter_interdependencies():
    # 记录开始时间
    start_time = time.process_time()

    # 创建连接
    conn = pymysql.connect(**db_config)

    # 创建一个游标对象
    cursor = conn.cursor()

    # 筛选互关
    互关 = """
        SELECT A.uid AS user1, A.screen_name AS screen_name1, "
           B.uid AS user2, B.screen_name AS screen_name2 "
        FROM weibo_user A 
        INNER JOIN weibo_user B ON A.uid = B.from_uid AND B.uid = A.from_uid 
        WHERE A.uid < B.uid;
        """
    cursor.execute(互关)

    # 结果
    data = cursor.fetchall()
    # 转换成 DataFrame
    columns = ["user1", "screen_name1", "user2", "screen_name2"]
    df = pd.DataFrame(data, columns=columns)
    # 导出 csv
    file_path = "/home/python/python-git/爬虫V2/互关.csv"
    df.to_csv(file_path, index=False)
    # 关系数
    data_count = df.shape[0]
    print("csv 导出成功，{} 条关系，耗时{:.3f}s".format(data_count, time.process_time() - start_time))

    cursor.close()
    conn.close()


def filter_nodes():
    # 记录开始时间
    start_time = time.process_time()

    # 创建连接
    conn = pymysql.connect(**db_config)

    # 创建一个游标对象
    cursor = conn.cursor()
    # 筛选节点数
    节点 = """
            SELECT COUNT(DISTINCT uid) AS total_unique_users 
            FROM (SELECT uid FROM weibo_user UNION SELECT from_uid FROM weibo_user) 
            AS combined_uids;
        """

    cursor.execute(节点)
    # 节点数
    node_count = cursor.fetchone()[0]
    print("共 {} 个节点，耗时{:.3f}s".format(node_count, time.process_time() - start_time))

    cursor.close()
    conn.close()


filter_nodes()
