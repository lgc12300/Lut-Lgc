-- 筛选互关
SELECT A.uid AS user1, A.screen_name AS screen_name1, B.uid AS user2, B.screen_name AS screen_name2

FROM user_relationship A
INNER JOIN user_relationship B ON A.uid = B.from_uid AND B.uid = A.from_uid
WHERE A.uid < B.uid;

-- 筛选节点数
SELECT COUNT(DISTINCT uid) AS total_unique_users
FROM (
    SELECT uid FROM user_relationship
    UNION
    SELECT from_uid FROM user_relationship
) AS combined_uids;