# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/5 8:49
@File ： edges_csv_to_nodes.py
@Auth ： markz
"""

"""
    使用 networkx 对边表进行转换，筛选出所有节点
"""
import networkx as nx
import pandas as pd

df = pd.read_csv("/home/python/python-git/爬虫V2/data/互关.csv")
G = nx.Graph(df)
print("当前节点数：", G.number_of_nodes())

nodes_list = [node for node in G.nodes]
df_nodes = pd.DataFrame(nodes_list, columns=["uid"])
df_nodes.to_csv("/home/python/python-git/爬虫V2/data/nodes.csv", index=False)
print("转换完毕")
