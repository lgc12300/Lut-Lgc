# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/1 22:12
@File ： csv_to_db.py
@Auth ： markz
"""

"""
    将百万级 csv 导入至 mysql
"""

import time

import pandas as pd

import pymysql

from sqlalchemy import create_engine

# 数据库连接信息
db_config = {
    "host": "localhost",
    "port": 3307,
    "user": "root",
    "password": "root",
    "database": "weibo_user",
    "charset": "utf8"
}

# 表名
table_name = "weibo_user"

start_time = time.process_time()
print("正在读取...")
csv_file_path = "/home/python/python-git/爬虫V2/data/merged_file.csv"
df = pd.read_csv(csv_file_path)
print("读取完成")

try:
    conn = pymysql.connect(**db_config)
    # 创建一个游标对象
    cursor = conn.cursor()
    print("数据库成功连接")

    # 使用SQLAlchemy的create_engine函数创建一个数据库连接引擎
    engine = create_engine(
        f"mysql+pymysql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{db_config['database']}")

    print("正在导入...")
    df.to_sql(table_name, con=engine, if_exists='replace', index=False)

    # 执行查询获取数据行数
    query = "SELECT COUNT(*) FROM " + table_name + ";"

    cursor.execute(query)
    row_count = cursor.fetchone()[0]

    print(f"导入完成，共 {row_count} 条数据。用时 {time.process_time() - start_time}s。")

    cursor.close()
    conn.close()

except pymysql.Error as e:
    print("数据库连接失败", e)
