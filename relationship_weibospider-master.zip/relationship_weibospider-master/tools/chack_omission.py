# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/5 19:54
@File ： chack_omission.py
@Auth ： markz
"""
import pandas as pd

df1 = pd.read_csv()
df2= pd.read_sql()