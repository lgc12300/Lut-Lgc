# -*- coding: utf-8 -*-
"""
@Time ： 2023/7/27 11:22
@File ： merged_csv.py
@Auth ： markz
"""

"""
    批量合并文件夹中 csv 文件
"""

# csv 文件夹路径
import os

import pandas as pd

from progress.bar import ShadyBar

folder_path = "/home/python/python-git/爬虫V2/data/friends"

# 获取文件夹中所有 csv 文件的文件名列表
file_names = [file for file in os.listdir(
    folder_path) if file.endswith(".csv")]

# 存储合并后的数据
merged_df = pd.DataFrame()

# 创建 ShadyBar 类的实例
bar = ShadyBar('开始合并:', max=len(file_names), bar_prefix=" ", bar_suffix=" ")  # 进度条

# 循环读取并合并所有 csv 文件
for file_name in file_names:
    file_path = os.path.join(folder_path, file_name)
    df = pd.read_csv(file_path, encoding='utf-8')
    merged_df = pd.concat([merged_df, df], ignore_index=True)
    bar.next()

bar.finish()
# 将合并后的数据保存到新的 csv 文件中
merged_file_path = "/home/python/python-git/爬虫V2/data/merged_file.csv"
merged_df.to_csv(merged_file_path, index=False)

print(f"成功将{file_names.__len__()}个 csv 文件合并为一个文件：{merged_file_path}")
