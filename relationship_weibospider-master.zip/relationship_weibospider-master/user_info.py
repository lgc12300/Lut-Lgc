# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/5 8:43
@File ： user.py
@Auth ： markz
"""

import pandas as pd

from collections import deque

from 爬虫V2.config import crawler_config

from 爬虫V2.core.get_user_info import UserInfo

from 爬虫V2.core.info_to_csv import file_exist, mkdir

from 爬虫V2.core.info_to_db import create_table, insert_user_info, close


def init(log_file_path=f"{crawler_config.log_dir}/user_info.log",
         file_path=f"{crawler_config.data_dir}/nodes.csv"):
    """
    初始化

    :param log_file_path: 日志文件路径
    :param file_path: csv 文件路径
    :return:
    """
    # 如果日志文件存在，有限读取日志文件。断点续爬
    if file_exist(log_file_path):
        df = pd.read_csv(log_file_path)
    else:
        df = pd.read_csv(file_path)  # 读取 csv 文件

    uids_deque = deque()  # 初始化双端队列

    # 将 uid 放入双端队列
    for uid in df["uid"]:
        uids_deque.append(uid)

    user = UserInfo(uid=crawler_config.uid, headers=crawler_config.headers)

    # 数据库建表
    create_table()

    return user, uids_deque


def write_log(uids_deque):
    """
    写日志，断点续传。记录还剩多少没爬

    :param uids_deque: 存放 uid 的双端队列
    :return:
    """
    if file_exist(crawler_config.log_dir) is False:
        mkdir(crawler_config.log_dir)

    # 日志文件，还剩多少没爬
    log = pd.DataFrame(list(uids_deque), columns=['uid'])
    log.to_csv(f"{crawler_config.log_dir}/user_info.log", index=False)


if __name__ == '__main__':
    """
        通过 uid 爬取个人信息
    """

    user, uids_deque = init()

    while len(uids_deque) != 0:
        uid = uids_deque.popleft()

        user_info = user.get_user_info(uid)
        print(user_info)
        print("剩余：{}".format(len(uids_deque)))
        insert_user_info(user_info)

        write_log(uids_deque)

    close()
    print("=" * 50)
    print("爬取完毕，请检查数据库")
