# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/5 10:10
@File ： info_to_db.py
@Auth ： markz
"""
import pymysql

from 爬虫V2.config.db_config import db_config, info_table

# 创建连接
conn = pymysql.connect(**db_config)


def create_table():
    """
    建表

    :return:
    """
    # 创建表（如果不存在）
    create_table_query = f"""
                   CREATE TABLE IF NOT EXISTS {info_table} (
                       uid VARCHAR(255) PRIMARY KEY,
                       screen_name VARCHAR(255),
                       friends_count BIGINT,
                       followers_count BIGINT,
                       verified BOOLEAN,
                       verified_reason TEXT,
                       sunshine_credit_level VARCHAR(255),
                       school VARCHAR(255),
                       location VARCHAR(255),
                       gender VARCHAR(255),
                       birthday VARCHAR(255),
                       constellation VARCHAR(255),
                       created_at DATETIME,
                       description TEXT
                   )
               """

    with conn.cursor() as cursor:
        cursor.execute(create_table_query)

    # 提交更改
    conn.commit()


def insert_user_info(data):
    """
    插入微博用户信息
    :param data: 信息数据字典
    :return:
    """

    # 将字段中的 ' 转义为 '' ; % 改为 %%
    # 避免 INSERT 出错
    if data["description"] is not None:
        data["description"] = data["description"].replace("'", "''")
        data["description"] = data["description"].replace("%", "%%")
    if data["screen_name"] is not None:
        data["screen_name"] = data["screen_name"].replace("'", "''")
    if data["school"] is not None:
        data["school"] = data["school"].replace("'", "''")
    if data["verified_reason"] is not None:
        data["verified_reason"] = data["verified_reason"].replace("'", "''")

    __VALUES = "(%(uid)s, '%(screen_name)s', %(friends_count)s,%(followers_count)s, %(verified)s, '%(verified_reason)s', '%(sunshine_credit_level)s','%(school)s', '%(location)s', '%(gender)s', '%(birthday)s', '%(constellation)s', '%(created_at)s', '%(description)s','未分类');" % data

    # 插入数据
    insert_query = f"""
    REPLACE INTO {info_table}
    (uid, screen_name, friends_count, followers_count,verified, verified_reason, sunshine_credit_level,school, 
        location, gender, birthday, constellation, created_at, description,circle)
    VALUES {__VALUES}
    """

    with conn.cursor() as cursor:
        cursor.execute(insert_query, data)

    # 提交更改
    conn.commit()


# 筛选互关
def close():
    conn.close()
