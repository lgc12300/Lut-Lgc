# -*- coding: utf-8 -*-

"""
@Time ： 2023/7/25 10:57
@File ：parse_uid.py
@Auth ： markz
"""
import requests


def parse_uid(uid, headers):
    """
    将字母 uid 解析为数字形式

    :param uid: 微博用户唯一标识
    :param headers: 标头
    :return: 存在则返回数字形式 uid；不存在返回 None
    """

    # uid 有两种：1. 纯数字，如：1809054937；2. 字符串，如：xiena
    try:
        uid = int(uid)  # 数字 uid
        return uid
    except:
        response = requests.get(url=f"https://weibo.com/ajax/profile/info?custom={uid}", headers=headers)
        try:
            return response.json()["data"]["user"]["id"]
        except:
            return None
