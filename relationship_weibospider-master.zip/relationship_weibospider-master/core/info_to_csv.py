# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/1 17:59
@File ： info_to_csv.py
@Auth ： markz
"""

import os

import pandas as pd

from 爬虫V2.config import crawler_config as config


def mkdir(dir_name):
    """
    如果文件夹不存在，则创建该文件夹

    :param dir_name: 文件夹名称
    :return:
    """

    if not os.path.exists(f"./{dir_name}"):
        os.makedirs(f"./{dir_name}")


def file_exist(file_name):
    """
    判断文件、文件夹是否存在

    :param file_name: 文件名称
    :return: 存在返回 True；不存在返回 False
    """

    if os.path.exists(file_name):
        return True
    else:
        return False


def count_files_in_folder(folder_path=config.friends_dir):
    """
    统计文件夹中文件数量

    :param folder_path:
    :return:
    """
    # 初始化文件计数器
    file_count = 0

    # 遍历文件夹中的所有文件和子文件夹
    for root, dirs, files in os.walk(folder_path):
        # 累加文件数量
        file_count += len(files)

    return file_count


def friends_info_to_csv(user_friends_info):
    """
    处理并记录好友数据，并保存为 csv

    :param user_friends_info: 好友信息列表
    :return: uid 存在则返回源 uid（是谁的朋友），不存在返回 None
    """

    from_uid = user_friends_info.get("from_uid", None)  # 是谁的朋友
    friends_count = user_friends_info.get("friends_count", None)  # 朋友数量
    all_friends_info = user_friends_info.get("friends_info", None)  # 朋友信息 dict

    mkdir(config.friends_dir)  # 创建文件夹
    # 创建 DataFrame
    df = pd.DataFrame(columns=['uid', "screen_name", 'from_uid'])

    # 没有关注则保存空 csv 或什么都不做
    if all_friends_info is None or friends_count == 0:
        # df.to_csv(f"{config.friends_dir}/{from_uid}.csv", index=False)  # 保存 csv
        return

    # 将每个朋友加入到 DataFrame 中
    for i, friend_info in enumerate(all_friends_info):
        friend_uid = friend_info.get("uid", None)
        friend_name = friend_info.get("screen_name", None)
        df.loc[i] = [friend_uid, friend_name, from_uid]

    df.to_csv(f"{config.friends_dir}/{from_uid}.csv", index=False)  # 保存 csv
    return from_uid


def error_info_to_csv(uid):
    """
    记录错误的 uid，这部分 uid 属于噪音。需要后期整理删除
    暂时用不到，添加了在爬取时跳过

    :param uid: 用户唯一标识
    :return:
    """

    file_name = f"{config.error_friends_dir}/error_uids.csv"

    # 如果文件夹不存在则创建文件夹
    mkdir(config.error_friends_dir)

    # 需要追加的数据
    error_info = {"uid": uid}
    new_data = pd.DataFrame.from_dict(error_info, orient='index').T

    # 如果 csv 文件存在，则读取文件并追加数据；否则，新建 csv
    if file_exist(file_name):
        new_data.to_csv(file_name, mode='a', index=False, header=False)
    else:
        new_data.to_csv(file_name, index=False)
