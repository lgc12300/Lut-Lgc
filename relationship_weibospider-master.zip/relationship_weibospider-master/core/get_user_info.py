# -*- coding: utf-8 -*-

"""
@Time ： 2023/8/1 8:57
@File ： get_user_info.py
@Auth ： markz
"""

from math import ceil

import requests

from 爬虫V2.core.parse_uid import parse_uid


class UserInfo:

    def __init__(self, uid, headers):
        self.__uid = uid
        self.__headers = headers

    def get_user_basic(self, uid=None, headers=None):
        """
        获取指定微博用户基本信息
        基本信息主页有两种形式，微博后台会自动进行转换：
        1. https://weibo.com/ajax/profile/info?custom=gonglinnamusic
        2. https://weibo.com/ajax/profile/info?uid=1234552257

        :param uid: 微博用户唯一标识
        :param headers: 标头
        :return: 用户基本信息：微博昵称、好友数量（关注数量）
        """

        # uid 有两种：1. 纯数字，如：1809054937；2. 字符串，如：xiena
        if uid is None:
            uid = self.__uid
        uid = parse_uid(uid=uid, headers=self.__headers)  # 说明是 xiena 这样的字符串，转换为数字 uid

        if not uid:
            return None

        if headers is None:
            headers = self.__headers

        response = requests.get(url=f"https://weibo.com/ajax/profile/info?uid={uid}", headers=headers)

        if response.status_code == 400:
            return {
                "errorMsg": "用户可能注销或者封号",
                "location": None,
                "user_link": f"https://weibo.com/{uid}"
            }

        # 获取 data
        try:
            resp_json = response.json().get("data", None)  # 尝试获取键为 "data" 的值，如果 "data" 键不存在，将 resp_json 赋值为 None
        except Exception as e:
            print("解析 json 有误：", e)
            resp_json = None

        if not resp_json:
            return None

        # 获取个人信息
        user = resp_json.get("user", None)
        if user is None:
            return None

        # 微博昵称
        screen_name = user.get("screen_name", None)

        # 关注数量
        friends_count = user.get("friends_count", None)

        # 粉丝数量
        followers_count = user.get("followers_count", None)

        # 属地
        location = user.get("location", None)

        # 是否 v 认证
        verified = user.get("verified", None)

        # 认证原因
        # 只有是 V 认证,才有认证原因
        if verified is True:
            verified_reason = user.get("verified_reason", None)
        else:
            verified_reason = None

        return {"screen_name": screen_name,
                "friends_count": friends_count,
                "location": location,
                "followers_count": followers_count,
                "verified": verified,
                "verified_reason": verified_reason
                }

    def get_user_detail(self, uid=None, headers=None):
        """
        获取指定微博用户详细信息

        :param uid: 微博用户唯一标识
        :param headers: 标头
        :return: 用户详细信息：uid、阳光信用值、属地、性别、生日、加微时间、简介、职业
        """

        # uid 有两种：1. 纯数字，如：1809054937；2. 字符串，如：xiena
        if uid is None:
            uid = self.__uid
        uid = parse_uid(uid=uid, headers=self.__headers)  # 说明是 xiena 这样的字符串，转换为数字 uid

        if not uid:
            return None

        if headers is None:
            headers = self.__headers

        response = requests.get(url=f"https://weibo.com/ajax/profile/detail?uid={uid}", headers=headers)

        if response.status_code == 400:
            return {
                "errorMsg": "用户可能注销或者封号",
                "user_link": f"https://weibo.com/{uid}"
            }

        # 获取 data
        try:
            resp_json = response.json().get("data", None)  # 尝试获取键为 "data" 的值，如果 "data" 键不存在，将 resp_json 赋值为 None
        except Exception as e:
            print(e)
            resp_json = None

        if not resp_json:
            return None

        # 阳光信用
        sunshine_credit = resp_json.get("sunshine_credit", None)
        if sunshine_credit:
            sunshine_credit_level = sunshine_credit.get("level", None)
        else:
            sunshine_credit_level = None

        # 教育信息
        education = resp_json.get("education", None)
        if education:
            school = education.get("school", None)
        else:
            school = None

        # 性别
        gender = resp_json.get("gender", None)
        # 微博性别是以 f/m 区分，转换为中文
        if gender is not None:
            if gender == "f":
                gender = "女"
            else:
                gender = "男"

        # 生日
        # 微博的生日包含出生日期和星座
        birthday = resp_json.get("birthday", None)
        constellation = None

        if birthday == '':
            birthday = None
        else:
            # 使用空格进行分割
            parts = birthday.split()
            try:
                # 获取生日
                birthday = parts[0]
                # 获取星座
                constellation = parts[1]
            except Exception as e:
                print("出生日期及星座获取失败！",e)
                birthday = None

        # 加微时间
        created_at = resp_json.get("created_at", None)

        # 简介
        description = resp_json.get("description", None)

        return {
            "uid": uid,
            "sunshine_credit_level": sunshine_credit_level,
            "school": school,
            "gender": gender,
            "birthday": birthday,
            "constellation": constellation,
            "created_at": created_at,
            "description": description
        }


    def get_user_friends_page_info(self, uid=None, headers=None, page=1, info=False):
        """
        获取指定微博用户基本信息

        :param uid: 微博用户唯一标识
        :param headers: 标头
        :param page: 当前页码，不指定则为第一页
        :param info: 是否获取信息
        :return: 用户基本信息：微博昵称、好友数量（关注数量）
        """

        # uid 有两种：1. 纯数字，如：1809054937；2. 字符串，如：xiena
        if uid is None:
            uid = self.__uid
        uid = parse_uid(uid=uid, headers=self.__headers)  # 说明是 xiena 这样的字符串，转换为数字 uid

        if not uid:
            return None

        if headers is None:
            headers = self.__headers

        response = requests.get(url=f"https://weibo.com/ajax/friendships/friends?page={page}&uid={uid}",
                                headers=headers)

        if response.status_code == 400:
            return {
                "errorMsg": "用户可能注销或者封号",
                "location": None,
                "user_link": f"https://weibo.com/{uid}"
            }

        # 获取 users （朋友信息）
        try:
            weibo_users = response.json().get("users", None)  # 尝试获取键为 "users" 的值，如果 "users" 键不存在，将 users 赋值为 None
        except Exception as e:
            print(e)
            weibo_users = None

        # 没获取到返回 None
        if not weibo_users:
            return None

        page_users_info = list()  # 当前页的朋友信息

        # 只记录朋友 uid
        if not info:
            for i in range(len(weibo_users)):
                page_users_info.append(weibo_users[i].get("id", None))
        # 多信息
        else:
            for i in range(len(weibo_users)):
                user_info = {"uid": weibo_users[i].get("id", None),
                             "screen_name": weibo_users[i].get("screen_name", None)}
                page_users_info.append(user_info)

        response.close()  # 每次请求完，主动关闭请求。避免 max retries exceeded 超过 http 连接数
        return page_users_info


    def get_user_friends_info(self, uid=None, headers=None, pages=99):
        """
        获取指定微博用户朋友信息（关注信息）

        :param uid: 微博用户唯一标识
        :param headers: 标头
        :param pages: 爬多少页，每页 20 条数据。貌似微博反爬机制或其他措施，最多只能爬 10 页。
        :return: 用户朋友信息（关注信息）
        {
            "from_uid": uid,
            "friends_count": fake_friends_count,
            "friends_info": users_info
        }
        """

        # uid 有两种：1. 纯数字，如：1809054937；2. 字符串，如：xiena
        if uid is None:
            uid = self.__uid
        uid = parse_uid(uid=uid, headers=self.__headers)  # 说明是 xiena 这样的字符串，转换为数字 uid

        if not uid:
            return {
                "error_code": 404,
                "error_msg": "uid 不存在",
                "uid": uid,
                "user_link": f"https://weibo.com/{uid}"
            }

        if headers is None:
            headers = self.__headers

        response = requests.get(url=f"https://weibo.com/ajax/friendships/friends?page=1&uid={uid}", headers=headers)

        if response.status_code == 400:
            return {
                "error_code": 404,
                "error_msg": "用户可能注销或者封号",
                "uid": uid,
                "user_link": f"https://weibo.com/{uid}"
            }

        try:
            # 尝试获取键为 "users" 的值，如果 "users" 键不存在，将 users 赋值为 None
            weibo_users = response.json().get("users", None)
        except Exception as e:
            print(e)
            weibo_users = None

        if weibo_users is None:
            return {
                "error_code": 404,
                "error_msg": "博主设置仅针对粉丝展示全部关注",
                "uid": uid,
                "user_link": f"https://weibo.com/{uid}"
            }

        # 获取朋友数量（关注数量）
        friends_count = response.json().get("total_number", None)
        # if friends_count == 0:
        #     return {
        #         "error_code": 404,
        #         "error_msg": f"{uid} 用户关注数为零",
        #         "uid": uid,
        #         "user_link": f"https://weibo.com/{uid}"
        #     }

        # 每页 20 条数据，爬出来的数据不一定每页都为 20 条，因为可能存在僵尸关注，或当前已销号的关注
        total_pages = ceil(friends_count / 20)  # 计算一共有多少页
        # 如果设定爬取页数大于总页数
        if total_pages > pages:
            total_pages = pages
        # 貌似微博反爬机制或其他措施，只能爬 10 页
        if total_pages > 10:
            total_pages = 10

        # 所有朋友用户（关注用户）信息
        users_info = list()

        # 翻页
        for page in range(1, total_pages + 1, 1):
            page_users_info = self.get_user_friends_page_info(uid=uid, page=page, info=True)  # 查询当前页朋友信息（关注信息）

            # 不为空则合并
            if page_users_info is not None:
                users_info = users_info + page_users_info

        # 实际爬取到的朋友数
        fake_friends_count = len(users_info)

        response.close()  # 每次请求完，主动关闭请求。避免 Max retries exceeded
        return {
            "from_uid": uid,
            "friends_count": fake_friends_count,
            "friends_info": users_info
        }


    def get_user_info(self, uid=None, headers=None):
        """
        获取用户信息

        :param uid: 微博用户唯一标识
        :param headers: 标头
        :return: 用户信息
        """

        # uid 有两种：1. 纯数字，如：1809054937；2. 字符串，如：xiena
        if uid is None:
            uid = self.__uid
        uid = parse_uid(uid=uid, headers=self.__headers)  # 说明是 xiena 这样的字符串，转换为数字 uid

        if not uid:
            return None

        if headers is None:
            headers = self.__headers

        # 获取用户信息
        user_info = {**self.get_user_basic(uid, headers), **self.get_user_detail(uid, headers)}

        return user_info
