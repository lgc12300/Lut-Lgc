# -*- coding: utf-8 -*-

"""
@Time ： 2023/9/21 15:26
@File ： clean_plot.py
@Auth ： markz
"""

import os

from datetime import datetime

import pandas as pd

import matplotlib.pyplot as plt

import numpy as np

file_name = "#79岁奶奶组乐队玩摇滚活得太酷了#[haha]"


def export_to_csv():
    """
    导出成 csv

    :return:
    """
    # 数据集目录
    dir_path = f"./data/{file_name}"
    # 获取文件夹中所有文件名
    files = os.listdir(dir_path)
    # 对文件名按日期排序
    files = sorted(files, key=lambda x: datetime.strptime(x, "%Y-%m-%d-%H-%M-%S.csv"))
    # file_times = [(file, os.path.getmtime(os.path.join(dir_path, file))) for file in files]
    # files = [i[0] for i in sorted(file_times, key=lambda x: x[1])]

    data_df = pd.DataFrame(columns=["话题", "转发数", "评论数", "点赞数"])
    for file in files:
        df = pd.read_csv(f"{dir_path}/{file}")
        if df.empty:
            continue
        cctv_news_row = df.loc[0]
        topic = cctv_news_row["topic"]
        likes = cctv_news_row["likes"]
        comments = cctv_news_row["comments"]
        reweibos = cctv_news_row["reweibos"]
        new_row = pd.DataFrame({"话题": topic, "点赞数": likes, "评论数": comments, "转发数": reweibos}, index=[0])
        data_df = pd.concat([data_df, new_row], ignore_index=True)

    data_df.to_csv(f"./data/{file_name}.csv")
    print("导出完成!")


def increment_density():
    """
    增量数据展示

    :return:
    """

    # 每分钟增量
    reweibos_increments = np.array([reweibos[i] - reweibos[i - 1] for i in range(1, len(reweibos))])
    comments_increments = np.array([comments[i] - comments[i - 1] for i in range(1, len(comments))])
    likes_increments = np.array([likes[i] - likes[i - 1] for i in range(1, len(likes))])
    # 绘制图表
    plt.figure(figsize=(8, 6))
    plt.plot(reweibos_increments, label="reweibos_increments")
    plt.plot(comments_increments, label="comments_increments")
    # plt.plot(likes_increments, label="likes_increments")
    plt.xlabel("T")
    plt.ylabel("Density")
    plt.title("increment_density")
    plt.legend()
    plt.show()


def reweibos_density():
    """
    累计绘图

    :return:
    """

    # 绘制图表
    plt.figure(figsize=(8, 6))
    plt.plot(reweibos, label="reweibos")
    # plt.plot(comments, label="comments")
    # plt.plot(likes, label="likes")
    plt.xlabel("T")
    plt.ylabel("Density")
    plt.title("reweibos_density")
    plt.legend()
    plt.show()

# export_to_csv()
df = pd.read_csv(f"./data/{file_name}.csv", index_col=[0])
df = df.iloc[::10].reset_index(drop=True)  # 隔十行取一个
reweibos = df["转发数"]
comments = df["评论数"]
likes = df["点赞数"]
# increment_density()
reweibos_density()
