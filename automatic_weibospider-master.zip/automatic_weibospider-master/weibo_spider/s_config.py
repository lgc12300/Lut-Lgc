# -*- coding: utf-8 -*-

"""
@Time ： 2023/9/10 21:43
@File ： s_config.py
@Auth ： markz
"""

UID = 2656274875  # 央视新闻
# UID = 1239246050  # 薛之谦

MBLOG = {'NtLEjxHlK': '#教育部部署2024考研安全工作#'}

COOKIE = "_T_WM=deb57cebc93dabaef9af47eb9be7935e; SCF=ArwslwkAXfOhve0a7wYv67vl4z9S-BNo1IQTHqIsaeZivqxj_-AmNORGB0OHSUkZfiomGDLnW84xWGOx4aUgGPQ.; SUB=_2A25IhXN8DeRhGeRM61ET8inIyDuIHXVr-4q0rDV6PUJbktANLXfTkW1NU-MUOWFdqjKrwd83B3peMjMUsMbyzPvo; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WhxCe2dVdWCB18SVTbFq8nK5NHD95QEeo50eozNSheNWs4Dqcj1i--fi-ihi-271K.cSoMt; SSOLoginState=170295377"

NUMBER = 1

MONITOR_NUMBER = 3

TIME_INTERVAL = 60 * 1  # 两分钟

TOTAL_TIME = 60 * 60 * 72  # 十五小时

TIME_RETRIES = 30  # 重连间隔

ROOT_DATA_DIR = "./data"

INTERPRETER = "/home/python/venv/bin/python"

DATA_DIR = './data/#教育部部署2024考研安全工作#'

HEADERS = {
    "authority": "weibo.com",
    "x-requested-with": "XMLHttpRequest",
    "sec-ch-ua-mobile": "?0",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "content-type": "application/x-www-form-urlencoded",
    "accept": "*/*",
    "sec-fetch-site": "same-origin",
    "sec-fetch-mode": "cors",
    "sec-fetch-dest": "empty",
    "referer": "https://weibo.com/u/2203227437",
    "accept-language": "zh-CN,zh;q=0.9,en-CN;q=0.8,en;q=0.7,es-MX;q=0.6,es;q=0.5",
    "connection": "close",
    "cookie": COOKIE
}

EMAIL = {
    "from_addrs": "1097732787@qq.com",
    "to_addrs": "1097732787@qq.com",
    "password": "wywwheajmnvphdjb",
    "subject": f"用户{UID}的微博更新了！"
}
