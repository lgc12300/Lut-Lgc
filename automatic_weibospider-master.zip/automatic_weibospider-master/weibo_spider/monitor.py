# -*- coding: utf-8 -*-

"""
@Time ： 2023/9/14 11:01
@File ： main.py
@Auth ： markz
"""

import os

import sched

import re

import time

import requests

from s_config import HEADERS, UID, NUMBER, EMAIL, TOTAL_TIME, TIME_INTERVAL, ROOT_DATA_DIR, INTERPRETER, TIME_RETRIES, \
    DATA_DIR

from tools import run_bash, send_email, modify_config

import logging


def get_mblogid():
    """
    获取 uid 微博主页中前 s_config.NUMBER 条微博 mblogid 列表

    返回值：
    示例：{"NiN2JCjMc":#广西梯田一眼治愈强迫症#", "NiNG940mf": "#共享单车车筐发现20万现金送交民警#"}

    :return: key: mid，value: topic
    """

    try:
        response = requests.get(url=f"https://weibo.com/ajax/statuses/mymblog?uid={UID}&page=1&feature=0",
                                headers=HEADERS)
        resp_json = response.json().get("data", None)
        _list = resp_json.get("list", None)
        d = {}  # mblogid_dict
        for i, value in enumerate(_list):
            # 检查是否为置顶微博。置顶微博永远排在第一个，因此跳过置顶微博。
            if value.get("isTop", None) is not None:
                continue

            if i >= NUMBER and d.__len__() > 0:
                break

            # 通配符获取标题
            text_raw = value.get("text_raw", None)
            pattern = r"【(.*?)】"
            topic = re.findall(pattern, text_raw)
            if topic:
                topic = topic[0]
                mblogid = value.get("mblogid", None)
                d[mblogid] = topic

        response.close()
        return d
    except Exception as e:
        logging.error(f"[ERROR] Request failed: {e}")
        logging.error(f"[ERROR] {TIME_RETRIES} 秒后重试")
        return {}


def check_updates():
    """
    检查是否更新新的微博

    :return: 如果更新微博返回 True；未更新返回 False
    """

    global mblogids_dict
    try:
        mblogids = list(mblogids_dict.keys())
        logging.info(f"当前标题：{list(mblogids_dict.values())[0]}")
        if mblogids is None:
            return False
        new_mblogids_dict = get_mblogid()
        new_mblogids = list(new_mblogids_dict.keys())
        if mblogids[0] != new_mblogids[0]:
            mblogids_dict = new_mblogids_dict
            return True
    except AttributeError as e:
        logging.error("[ERROR] 请检查 cookie 或其他配置")
        return False

    return False


def _task(sc):
    """
    定时任务

    :param sc:
    :return:
    """

    elapsed_time = time.time() - start_time  # 计算经过时间

    # 递归出口
    if elapsed_time < TOTAL_TIME:
        if check_updates():
            logging.info("微博更新被侦测!")
            # 修改配置文件
            modify_config("MBLOG", mblogids_dict)
            new_data_dir = f"{ROOT_DATA_DIR}" + "/" + str(list(mblogids_dict.values())[0])
            modify_config("DATA_DIR", f"'{new_data_dir}'")
            # 创建目录
            logging.info("正在创建目录!")
            os.mkdir(f"{new_data_dir}")
            # 发送邮件提醒
            logging.info(f"发送更新 Email 至 {EMAIL.get('to_addrs')}")
            send_email(**EMAIL, mail_text=str(mblogids_dict))
            # 运行爬虫
            run_bash("cd weibo_spider")
            run_bash(f"{INTERPRETER} ./spider.py")
            exit()

        # 递归调度
        sc.enter(TIME_INTERVAL, 1, _task, (sc,))


def _init():
    """
    程序初始化操作

    :return:
    """

    # 初始化 data 目录
    if not os.path.exists(f"{ROOT_DATA_DIR}"):
        os.mkdir(f"{ROOT_DATA_DIR}")
    # 初始化日志生成器
    logging.basicConfig(format="[%(asctime)s] %(message)s", datefmt="%H:%M:%S", level=logging.INFO)
    c = 0  # 记录监控个数
    st = time.time()
    logging.info("初始化完毕！")

    return c, st


if __name__ == '__main__':
    count, start_time = _init()
    logging.info("监控服务已启动...")
    logging.info(f"将在 1 个更新后停止监控")
    mblogids_dict = get_mblogid()
    scheduler = sched.scheduler(time.time, time.sleep)
    _task(scheduler)
    scheduler.run()
    logging.info(f"已结束操作,运行时间：{(TOTAL_TIME / 60 / 60)}")
    logging.info(f"文件保存位置：{DATA_DIR}")
