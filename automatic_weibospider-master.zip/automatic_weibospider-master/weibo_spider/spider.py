# -*- coding: utf-8 -*-

"""
@Time ： 2023/9/10 21:18
@File ： main.py
@Auth ： markz
"""

import logging

import sched

import time

import datetime

import pandas as pd

import requests

from s_config import TOTAL_TIME, TIME_INTERVAL, HEADERS, DATA_DIR, MBLOG, TIME_RETRIES


def get_reweibos():
    """
    根据 mblogid_dict 获取微博的转发、评论、点赞数

    :return: 单个时间间隔内的 mblogid 转发、评论、点赞
    """

    for i in mblogid_dict.items():
        mblogid = i[0]
        try:
            response = requests.get(url=f"https://weibo.com/ajax/statuses/show?id={mblogid}&locale=zh-CN",
                                    headers=HEADERS)
            reposts_count = response.json().get("reposts_count", None)
            comments_count = response.json().get("comments_count", None)
            attitudes_count = response.json().get("attitudes_count", None)
            d = {"topic": i[1], "reweibos": reposts_count, "comments": comments_count, "likes": attitudes_count}
            logging.info(str(d))
            response.close()
            yield d
        except Exception as e:
            logging.error(f"[ERROR] Request failed: {e}")
            logging.error(f"[ERROR] {TIME_RETRIES} 秒后重试")
            time.sleep(30)
            yield None
            continue


def _task(sc):
    """
    定时任务

    :param sc:
    :return:
    """

    elapsed_time = time.time() - start_time  # 计算经过时间

    # 递归出口
    if elapsed_time < TOTAL_TIME:
        data = get_reweibos()
        df = pd.DataFrame(columns=["topic", "reweibos", "comments", "likes"])
        for _, v in mblogid_dict.items():
            d = next(data)
            if d is not None:
                df = pd.concat([df, pd.DataFrame(d, index=[0])], ignore_index=True)
                # 递归调度
                sc.enter(TIME_INTERVAL, 1, _task, (sc,))
            else:
                # 递归调度
                sc.enter(TIME_RETRIES, 1, _task, (sc,))
        df.to_csv(f"{DATA_DIR}/{datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv")


def _init():
    """
    程序初始化操作

    :return:
    """

    logging.basicConfig(format="[%(asctime)s] %(message)s", datefmt="%H:%M:%S", level=logging.INFO)
    logging.info("初始化完毕！")


if __name__ == "__main__":
    _init()

    logging.info("爬虫已启动...")
    mblogid_dict = MBLOG
    start_time = time.time()
    scheduler = sched.scheduler(time.time, time.sleep)
    _task(scheduler)
    scheduler.run()
