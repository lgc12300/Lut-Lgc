# -*- coding: utf-8 -*-

"""
@Time ： 2023/9/16 15:02
@File ： logging.py
@Auth ： markz
"""

import datetime

import subprocess

import smtplib

from email.header import Header

from email.mime.text import MIMEText


def send_email(from_addrs, to_addrs, password, subject, mail_text):
    """
    发送邮件

    :param from_addrs: 发送邮箱
    :param to_addrs: 接受邮箱
    :param password: 验证码
    :param subject: 主题
    :param mail_text: 邮件内容
    :return:
    """

    smtp_obj = smtplib.SMTP("smtp.qq.com", 587)
    smtp_obj.login(from_addrs, password)
    msg_body = MIMEText(mail_text, "plain", "utf-8")
    msg_body["From"] = Header(f"markz<{from_addrs}>")
    msg_body["Subject"] = Header(subject, "utf-8")
    smtp_obj.sendmail(from_addrs, to_addrs, msg_body.as_string())
    logging(f"邮件发送完毕!主题：{subject}")


def logging(message):
    """
    打印输出日志

    :param message: 消息
    :return: 示例：[09:05:57] 监控服务已启动...
    """

    now = "[" + str(datetime.datetime.now().strftime('%H:%M:%S')) + "]"
    print(now + " " + message)


def run_bash(command):
    logging(f"正在运行 bash 命令：{command}")
    subprocess.run(command, shell=True)


def modify_config(k, v):
    """
    修改配置文件中的属性

    :param k: 属性名
    :param v: 值
    :return:
    """

    logging(f"正在修改配置 {k}")

    # 读配置
    with open("s_config.py", "r") as file:
        config_lines = file.readlines()

    new_config_lines = []
    for line in config_lines:
        if line.startswith(f"{k}"):
            new_config_lines.append(f"{k} = {v}\n")
        else:
            new_config_lines.append(line)

    # 写配置
    with open("s_config.py", "w") as file:
        file.writelines(new_config_lines)
