<html lang="zh">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .icon-button {
            background-color: #3498db;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 50px;
        } 
        .author-info-container {
            text-align: center;
            margin-top: 20px;
        }
        .author-info {
            display: inline-block;
            text-align: left;
            font-size: 16px;
            padding: 10px;
            color: darkgray;
            border-radius: 3px;
        }
    </style>
    <body>
        <h1 align="center">微博行为爬虫</h1>
        <div align="center">
                <img align="center" src="https://img.tukuppt.com/png_preview/00/06/95/sgjCp3vU5O.jpg%21/fw/780" width="500px" alt="微博logo">
        </div>
        <div class="author-info-container">
            <div class="author-info">
                <i class="fas fa-user icon">&nbsp;&nbsp;
markz</i><br>
                <i class="fa-solid fa-paper-plane">&nbsp;&nbsp;
1097732787@qq.com</i><br>
                <i class="fa-solid fa-clock">&nbsp;&nbsp;
2023.9.10</i>
            </div>
        </div>
        <div align="center" style="margin-top: 15px">
            <a class="icon-button" href="https://github.com/zhang99667">
                <i class="fab fa-github"> GitHub</i>
            </a>
            <a class="icon-button" href="https://gitee.com/for-freedom996">
                <i class="fab fa-git"> gitee</i>
            </a>
            <a class="icon-button" href="https://weibo.com/u/2203227437">
                <i class="fab fa-weibo"> weibo</i> 
            </a>
        </div>
    </body>
</html>

## 先行条件

1. 详细查看`s_config`中的配置信息，并对其修改
2. 对下述的 `interpreter` 路径进行修改

## 运行程序

两种使用方式：
 1. 运行监控服务（检测到微博更新自动启动爬虫）
 2. 运行爬虫（手动选择爬取指定微博）

采集的数据存在`#topic_name#`文件夹中，命名为`{datetime}.csv`

### 监控服务

```bash
cd weibo_spider
/home/python/venv/bin/python ./monitor.py
```

### 爬虫服务

```bash
cd weibo_spider
/home/python/venv/bin/python ./spider.py
```

```csv
,topic,reweibos,comments,likes
0,#黑龙江漠河正式供暖#,91,207,714
```